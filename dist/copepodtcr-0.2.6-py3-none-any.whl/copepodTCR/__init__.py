from importlib.metadata import version
__version__ = version("copepodTCR")

from copepodTCR.functions import *