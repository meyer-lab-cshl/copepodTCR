# Combinatorial peptide pooling

## Intro

This python package provides an algorithm for combinatorial peptide pooling. It is able to provide a used with a peptide pooling scheme, run simple experimental simulation with given peptides, and to determine which peptide led to activation of T-cell in the experiment with given peptide pooling scheme.

### Task


## Algorithm

## Installation

## Usage

### Requirements

### Shiny App

### Recommended parameters