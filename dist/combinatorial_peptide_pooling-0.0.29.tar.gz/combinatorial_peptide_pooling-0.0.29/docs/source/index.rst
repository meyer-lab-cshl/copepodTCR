.. Combinatorial peptide pooling documentation master file, created by
   sphinx-quickstart on Mon Oct  9 18:14:27 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
=============================
Combinatorial peptide pooling
=============================

.. toctree::
   :maxdepth: 2
   :caption: Combinatorial peptide pooling

   Introduction
   Installation
   Requirements
   Usage
   ShinyApp
   Recommended_parameters