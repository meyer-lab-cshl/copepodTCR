Requirements
--------------------

pandas>=1.5.3

numpy>=1.23.5

cvxpy>=1.3.2

trimesh>=3.23.5