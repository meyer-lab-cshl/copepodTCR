Combinatorial peptide pooling
=======================================