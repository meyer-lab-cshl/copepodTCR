Recommended parameters
------------------------------