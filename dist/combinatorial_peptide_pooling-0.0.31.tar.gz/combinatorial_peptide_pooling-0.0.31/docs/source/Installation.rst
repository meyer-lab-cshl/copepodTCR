Installation
=============================

You can install the package with pip:

``pip install combinatorial_peptide_pooling``

Or with conda:

``conda install -c vasilisa.kovaleva combinatorial_peptide_pooling``