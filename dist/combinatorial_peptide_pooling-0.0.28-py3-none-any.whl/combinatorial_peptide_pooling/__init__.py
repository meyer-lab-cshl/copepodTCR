from importlib.metadata import version
__version__ = version("combinatorial_peptide_pooling")

from combinatorial_peptide_pooling.functions import *